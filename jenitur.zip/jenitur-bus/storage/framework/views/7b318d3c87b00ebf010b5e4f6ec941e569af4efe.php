<?php $__env->startSection('title', 'Jenitur'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Usuários</h1>
<?php $__env->stopSection(); ?>

<style>
	#example1 {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	border-collapse: collapse;
	width: 100%;
	}

	#example1 td, #example1 th {
	border: 1px solid #ddd;
	padding: 8px;
	color: #777;
	}

	#example1 tr:nth-child(even){background-color: #f2f2f2;}

	#example1 tr:hover {background-color: #ddd;}

	#example1 th {
	padding-top: 12px;
	padding-bottom: 12px;
	text-align: left;
	background-color: #fff;
	color: #666;
	}
</style>

<?php $__env->startSection('content'); ?>

	
            <!-- Button to Open the Modal -->
			<button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal">
				Adicionar Usuario
			</button>


			<!-- The Modal -->
			<div class="modal" id="myModal">
			<div class="modal-dialog">
				<div class="modal-content">

				<!-- Modal Header -->
				<div class="modal-header">
					<h4 class="modal-title">Adicionar Usuário</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>

				<!-- Modal body -->
				<form action="<?php echo e(route('usuario.store')); ?>" method="post">
					<?php echo csrf_field(); ?>
					<div class="modal-body">
							<div class="box-body">
								<div class="form-group">
								
									<label>Nome Completo</label>
									<input type="text" class="form-control" name="name" required>

								</div>

								<div class="form-group">
								
									<label>Email</label>
									<input type="email" class="form-control" name="email" required>

								</div>

								<div class="form-group">
								
									<label>Permissão</label>
                                    <select name="permission" class="form-control">
                                        <option value="ADM">Administrador</option>
                                        <option value="MOD">Moderador</option>
                                    </select>

								</div>

								<div class="form-group">
								
									<label>Senha</label>
									<input type="password" class="form-control" name="password" required>

								</div>

								
							</div>
					</div>

					<!-- Modal footer -->
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Cadastrar</button>
					</div>
				</form>

				</div>
			</div>
			</div>

			<div class="box-body" style="overflow: auto;">
              <table id="example1" class="table table-bordered">
                <tr>
				  
                  <th>Nome</th>
                  <th>Email</th>
				  <th>Permissão</th>
				  <th>Ação</th>
                </tr>

		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
					<td><?php echo e($user->name); ?></td>
					<td><?php echo e($user->email); ?></td>
					<td><?php echo e($user->permission); ?></td>
					<td>
						<a href="<?php echo e(route('usuario.delete', [$user->id])); ?>"><i class="fas fa-trash"></i></a>
						<a href="<?php echo e(route('usuario.edit', [$user->id])); ?>"><i class="fas fa-edit"></i></a>
					</td>
					
					
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Breno\Desktop\jenitur-bus\resources\views/pages/usuarios.blade.php ENDPATH**/ ?>