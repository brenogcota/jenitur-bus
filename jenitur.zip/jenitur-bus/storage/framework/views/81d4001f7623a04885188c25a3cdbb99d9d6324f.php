<?php $__env->startSection('title', 'Jenitur'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar usuário</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

                
    <!-- general form elements -->
    <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
            </div>

          
            
            <form action="<?php echo e(route('usuario.update', [$user->id] )); ?>" method="post" role="form">
                    <?php echo csrf_field(); ?>
              <div class="box-body">
               
                <div class="form-group">
                  
                        <label>Nome</label>
						<input class="form-control" value="<?php echo e($user->name); ?>" name="nome" required>

                </div>

                <div class="form-group">
    
                         <label>Email</label>
						 <input type="text" value="<?php echo e($user->email); ?>" class="form-control" name="email" required>

                </div>

                <div class="form-group">
    
                         <label>Permissão</label>
                         <select  class="form-control" name="permissao" id="">
                            <option value="ADM">Administrador</option>
                            <option value="MOD">Moderador</option>
                         </select>
                </div>

                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Atualizar</button>
              </div>
            </form>
          </div>
          
          <!-- /.box -->
<?php $__env->stopSection(); ?>

<script type="text/javascript">

  function getBoard(value) {
    document.getElementById("poltrona").innerHTML = "Poltrona: " + value;
  }
	function bloqueio() {
        	if (document.getElementById("destinyDateHour").style.display == "block"){
                 document.getElementById("destinyDateHour").style.display = "none";
            } else {
                document.getElementById("destinyDateHour").style.display = "block";	  	  
              }  
              
    }


    
</script>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Breno\Desktop\jenitur-bus\resources\views/pages/edit-user.blade.php ENDPATH**/ ?>