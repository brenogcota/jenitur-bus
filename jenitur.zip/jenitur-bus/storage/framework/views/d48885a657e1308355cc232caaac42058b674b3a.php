<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale-1">
		<title>Viagens - Jenitur Turismo</title>

		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilo.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('https://use.fontawesome.com/releases/v5.4.2/css/all.css')); ?>">
		<link href="<?php echo e(asset('https://fonts.googleapis.com/css?family=Noto+Sans+JP:400,900&display=swap')); ?>" rel="stylesheet">

	</head>
	<body>
		<nav class="menu">
			<div class="logo">
				<div class="logo1">
					<h1 align="center">JENITUR</h1>
				</div>
				<div class="logo2">
					<h3 align="center">Turismo</h3>
				</div>
			</div>
			<a class="btn-close"><i class="fa fa-times"></i></a>
			<ul>
				<a href="/viagem/cadastrar"><li> Cadastrar Viagem </li></a>
				<a href="/viagens"><li> Cadastrar Passageiro </li></a>
				<a href="/relatorio"><li> Relatórios </li></a>
				<a href="/login"><li style="margin-top: 50%"> Sair </li></a>
			</ul>
		</nav>

		<button class="btn-menu"><i class="fa fa-bars fa-lg"></i></button>

		<!--Secao com todas as viagens cadastradas-->
		<content class="viagens">
			<div class="top">
				<h1>Escolha a Viagem</h1>
			</div>
			<!--A estrutura de repeticao deve comecar aqui-->
			<?php $__currentLoopData = $trip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
			<a href="<?php echo e(route('passageiro.create', [$t->id])); ?>">
				<div class="viagem">
					<!--Cidade origem     Estado origem-->
					<p> <?php echo e($t->ORIGEM); ?> </p>
					
					<i class="fas fa-chevron-right"></i>
					<i class="fas fa-chevron-right"></i>
					<i class="fas fa-chevron-right"></i>
					
					<!--Cidade destino     Estado destino-->
					<p> <?php echo e($t->DESTINO); ?> </p><br>
									     <!--Data da viagem-->
					<p>Data: &nbsp <span>  <?php echo e($t->DATA); ?> </span></p>
									        <!--Veiculo-->
					<p>Placa: &nbsp <span> <?php echo e($t->PLACAVEICULO); ?>  </span></p><br>
										  <!--Horario-->
					<p>Horário: &nbsp <span> <?php echo e($t->HORARIO); ?>  </span></p><br>

						<p>Status: &nbsp <span class="status"><?php echo e($t->STATUS); ?></span></p>
				</div>
			</a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</content>
		

		<!--JQUERY-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script>
			$(".btn-menu").click(function(){
				$(".menu").show();
			})
			$(".btn-close").click(function(){
				$(".menu").hide();
			})
		</script>
	</body>
</html>
<?php /**PATH C:\Users\Breno\Desktop\jenitur\resources\views/pages/viagens.blade.php ENDPATH**/ ?>