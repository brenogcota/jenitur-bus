<!DOCTYPE html>
<html>
<head>
	<title>show</title>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilo.css')); ?>">
	<link href="<?php echo e(asset('/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('https://fonts.googleapis.com/css?family=Noto+Sans+JP:400,900&display=swap')); ?>" rel="stylesheet">

</head>
<body>

	<?php if($passenger): ?>
		<?php $__currentLoopData = $passenger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <p><?php echo e($p->NOME); ?></p>
			<p><?php echo e($p->DATANASC); ?></p>
			<hr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
	
</body>
</html><?php /**PATH C:\Users\Breno\Desktop\jenitur\resources\views/show.blade.php ENDPATH**/ ?>