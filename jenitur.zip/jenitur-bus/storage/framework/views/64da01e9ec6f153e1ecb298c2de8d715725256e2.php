<?php $__env->startSection('title', 'Jenitur'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Relatório de viagens</h1>
<?php $__env->stopSection(); ?>

<style>
	#example1 {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	border-collapse: collapse;
	width: 100%;
	}

	#example1 td, #example1 th {
	border: 1px solid #ddd;
	padding: 8px;
	color: #777;
	}

	#example1 tr:nth-child(even){background-color: #f2f2f2;}

	#example1 tr:hover {background-color: #ddd;}

	#example1 th {
	padding-top: 12px;
	padding-bottom: 12px;
	text-align: left;
	background-color: #fff;
	color: #666;
	}
</style>

<?php $__env->startSection('content'); ?>

	
			<a href="<?php echo e(route('relatorio-viagem.pdf')); ?>">Gerar Relatorio</i></a>
			<div class="box-body">
              <table id="example1" class="table table-bordered">
                <tr>
				  <th>#</th>
                  <th>Origem</th>
                  <th>Destino</th>
				  <th>Data</th>
				  <th>Placa</th>
				  <th>Horario</th>
				  <th>Status</th>
                </tr>

		<?php $__currentLoopData = $trip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		
			
					<tr>
					<td><a href="<?php echo e(route('passageiro.show', [$t->id])); ?>"><i class="fas fa-eye"></i></a></td>
					<td><?php echo e($t->ORIGEM); ?></td>
					<td><?php echo e($t->DESTINO); ?></td>
					<td><?php echo e($t->DATA); ?></td>
					<td><?php echo e($t->PLACAVEICULO); ?></td>
					<td><?php echo e($t->HORARIO); ?> </td>
					<td><span class="label label-success"><?php echo e($t->STATUS); ?></span></td>
					</tr>
					
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Breno\Documents\jenitur\resources\views/pages/relatorio.blade.php ENDPATH**/ ?>