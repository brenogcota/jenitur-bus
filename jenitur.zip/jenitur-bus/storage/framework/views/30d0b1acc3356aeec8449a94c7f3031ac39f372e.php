<?php $__env->startSection('title', 'Jenitur'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Passageiros</h1>
<?php $__env->stopSection(); ?>

<style>
	#example1 {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	border-collapse: collapse;
	width: 100%;
	}

	#example1 td, #example1 th {
	border: 1px solid #ddd;
	padding: 8px;
	color: #777;
	}

	#example1 tr:nth-child(even){background-color: #f2f2f2;}

	#example1 tr:hover {background-color: #ddd;}

	#example1 th {
	padding-top: 12px;
	padding-bottom: 12px;
	text-align: left;
	background-color: #fff;
	color: #666;
	}
</style>

<?php $__env->startSection('content'); ?>

			<?php
                $url = $_SERVER["REQUEST_URI"];
                $arr = explode("/", $url);
                $di = $arr[2];
                
            ?>
				<a href="<?php echo e(route('relatorio-passageiros.pdf', [$di])); ?>" target="_blank">Gerar Relatorio</i></a>
                <div class="box-body" style="overflow: auto;">
                <table id="example1" class="table table-bordered">
                    <tr>
                    <th>Nome</th>
                    <th>CPF</th>
                    <th>RG</th>
                    <th>Poltrona</th>
                    <th>Telefone</th>
                    <th>Tel. Reserva</th>
					<th>Criança</th>
                    <th>Nome</th>
                    <th>Documento</th>
					<th>Poltrona criança</th>
					<th>Func. cad</th>
					<th>Ação</th>
                    </tr>

        <?php $__currentLoopData = $passenger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		
					<tr>
					<td><?php echo e($p->NOME); ?></td>
					<td><?php echo e($p->CPF); ?></td>
					<td><?php echo e($p->RG); ?></td>
                    <td><?php echo e($p->POLTRONA); ?> </td>
					<td><?php echo e($p->TELEFONE1); ?></td>
                    <td><?php echo e($p->TELEFONE2); ?></td>
					<td><?php echo e($p->POSSCRIANCA); ?></td>
					<td><?php echo e($p->NOMECRIANCA); ?> </td>
                    <td><?php echo e($p->DOCCRIANCA); ?> </td>
					<td><?php echo e($p->POLTRONA_ACOMPANHANTE); ?></td>
					<td><?php echo e($p->USUARIO); ?></td>
					<td>
						<a href="<?php echo e(route('passageiro.delete', [$p->id])); ?>"><i class="fas fa-trash"></i></a>
						<a href="<?php echo e(route('passageiro.edit', [$di, $p->id])); ?>"><i class="fas fa-edit"></i></a>
					</td>
					</tr>
					
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Breno\Desktop\jenitur-bus\resources\views/pages/passageiros.blade.php ENDPATH**/ ?>